// eslint-disable-next-line ts/ban-ts-comment
// @ts-nocheck
/* eslint-disable perfectionist/sort-exports */


export { default as pluginAntfu } from 'eslint-plugin-antfu';
export * as pluginImport from 'eslint-plugin-i';
export { default as pluginPreferArrow } from 'eslint-plugin-prefer-arrow';
export { default as pluginJs } from '@eslint/js';
export { default as pluginTs } from '@typescript-eslint/eslint-plugin';
export { default as pluginPerfectionist } from 'eslint-plugin-perfectionist';
export { default as pluginPerfectionistRecommendedAlphabetical } from 'eslint-plugin-perfectionist/configs/recommended-alphabetical';
export { default as pluginPromise } from 'eslint-plugin-promise';
export * as pluginSonar from 'eslint-plugin-sonarjs';
export { default as pluginStylistic } from '@stylistic/eslint-plugin';
export { default as pluginUnicorn } from 'eslint-plugin-unicorn';
export { default as pluginUnusedImports } from 'eslint-plugin-unused-imports';
export { default as pluginVue } from 'eslint-plugin-vue';
export { default as pluginTailwind } from 'eslint-plugin-tailwindcss';

export * as parserTs from '@typescript-eslint/parser';
export { default as parserVue } from 'vue-eslint-parser';
