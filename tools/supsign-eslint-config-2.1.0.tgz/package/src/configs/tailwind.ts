import type { FlatConfigItem } from '../types';

import { pluginTailwind } from '../plugins';


export async function tailwind(): Promise<FlatConfigItem[]> {
  return [
    {
      name: 'supsign:tailwind',
      plugins: {
        tailwindcss: pluginTailwind
      },
      rules: {
        ...pluginTailwind.configs.recommended.rules as any,
        'tailwindcss/no-custom-classname': 'off'
      }
    }
  ];
}
