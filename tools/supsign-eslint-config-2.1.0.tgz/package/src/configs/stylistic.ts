import type { FlatConfigItem, StylisticConfig } from '../types';

import { pluginAntfu } from '../plugins';
import { interopDefault } from '../utils';

export async function stylistic(options: StylisticConfig = {}): Promise<FlatConfigItem[]> {
  const {
    indent = 2,
    jsx = true,
    quotes = 'single',
    semi = true
  } = options;


  const pluginStylistic = await interopDefault(import('@stylistic/eslint-plugin'));

  const config = pluginStylistic.configs.customize({
    flat: true,
    indent,
    jsx,
    pluginName: 'style',
    quotes,
    semi
  });

  return [
    {
      name: 'supsign:stylistic',
      plugins: {
        antfu: pluginAntfu,
        style: pluginStylistic
      },
      rules: {
        ...config.rules,

        'antfu/consistent-list-newline': 'error',
        'antfu/indent-binary-ops': ['error', { indent }],
        'antfu/top-level-function': 'error',
        'style/comma-dangle': ['error', 'never'],
        'style/member-delimiter-style': ['error', {
          overrides: {
            interface: {
              multiline: {
                delimiter: 'semi',
                requireLast: true
              }
            }
          }
        }]
      }
    }
  ];
}
