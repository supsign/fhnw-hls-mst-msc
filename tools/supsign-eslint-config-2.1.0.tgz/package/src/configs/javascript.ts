import globals from 'globals';

import type { FlatConfigItem, OptionsIsInEditor, OptionsOverrides } from '../types';

import { GLOB_SRC, GLOB_SRC_EXT } from '../globs';
import { pluginAntfu, pluginJs, pluginUnusedImports } from '../plugins';


export async function javascript(
  options: OptionsIsInEditor & OptionsOverrides = {}
): Promise<FlatConfigItem[]> {
  const {
    isInEditor = false,
    overrides = {}
  } = options;

  return [
    {
      languageOptions: {
        ecmaVersion: 2022,
        globals: {
          ...globals.browser,
          ...globals.es2021,
          ...globals.node,
          document: 'readonly',
          navigator: 'readonly',
          window: 'readonly'
        },
        parserOptions: {
          ecmaFeatures: {
            jsx: true
          },
          ecmaVersion: 2022,
          sourceType: 'module'
        },
        sourceType: 'module'
      },
      linterOptions: {
        reportUnusedDisableDirectives: true
      },
      name: 'supsign:javascript',
      plugins: {
        'antfu': pluginAntfu,
        'unused-imports': pluginUnusedImports
      },
      rules: {
        ...pluginJs.configs.recommended.rules,
        'default-case': 'error',
        'dot-notation': 'error',
        'eqeqeq': ['error', 'always'],
        'func-call-spacing': 'error',
        'no-array-constructor': 'error',
        'no-duplicate-imports': 'error',
        'no-else-return': 'error',
        'no-lonely-if': 'error',
        'no-undef-init': 'error',
        'no-unreachable-loop': 'error',
        'no-useless-rename': 'error',
        'no-useless-return': 'error',
        'require-await': 'error',
        'template-curly-spacing': ['error', 'never'],
        'unused-imports/no-unused-imports': isInEditor ? 'off' : 'error',
        'unused-imports/no-unused-vars': [
          'error',
          { args: 'after-used', argsIgnorePattern: '^_', vars: 'all', varsIgnorePattern: '^_' }
        ],
        ...overrides
      }
    },
    {
      files: [`scripts/${GLOB_SRC}`, `cli.${GLOB_SRC_EXT}`],
      name: 'antfu:scripts-overrides',
      rules: {
        'no-console': 'off'
      }
    }
  ];
}
