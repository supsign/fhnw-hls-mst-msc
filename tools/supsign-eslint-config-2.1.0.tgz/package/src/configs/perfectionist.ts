import type { FlatConfigItem } from '../types';

import { pluginPerfectionist, pluginPerfectionistRecommendedAlphabetical } from '../plugins';


/**
 * Optional perfectionist plugin for props and items sorting.
 *
 * @see https://github.com/azat-io/eslint-plugin-perfectionist
 */
export async function perfectionist(): Promise<FlatConfigItem[]> {
  return [
    {
      name: 'supsign:perfectionist',
      plugins: {
        perfectionist: pluginPerfectionist
      },
      rules: {
        ...pluginPerfectionistRecommendedAlphabetical.rules,
        'perfectionist/sort-vue-attributes': 'off'
      }
    }
  ];
}
