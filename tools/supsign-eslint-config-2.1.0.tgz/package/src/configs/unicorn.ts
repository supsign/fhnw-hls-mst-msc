import type { FlatConfigItem } from '../types';

import { pluginUnicorn } from '../plugins';

export async function unicorn(): Promise<FlatConfigItem[]> {
  return [
    {
      name: 'supsign:unicorn',
      plugins: {
        unicorn: pluginUnicorn
      },
      rules: {
        ...pluginUnicorn.configs.recommended.rules,
        'unicorn/filename-case': 'off', // Better ignore vue files. Find out how.
        'unicorn/no-useless-undefined': 'off',
        'unicorn/prevent-abbreviations': [
          'error',
          {
            replacements: {
              props: {
                properties: false
              },
              ref: {
                reference: false
              }
            }
          }
        ]
      }

    }
  ];
}

