import type { FlatConfigItem, OptionsComponentExts, OptionsFiles, OptionsOverrides, OptionsTypeScriptParserOptions, OptionsTypeScriptWithTypes } from '../types';

import { pluginSonar } from '../plugins';
import { interopDefault, toArray } from '../utils';

export async function sonar(
  options: OptionsFiles & OptionsComponentExts & OptionsOverrides & OptionsTypeScriptWithTypes & OptionsTypeScriptParserOptions = {}
): Promise<FlatConfigItem[]> {
  const {
    parserOptions = {}
  } = options;

  const tsconfigPath = options?.tsconfigPath
    ? toArray(options.tsconfigPath)
    : undefined;

  const [
    parserTs
  ] = await Promise.all([
    interopDefault(import('@typescript-eslint/parser'))
  ] as const);

  return [
    {
      languageOptions: {
        parser: parserTs,
        parserOptions: {
          sourceType: 'module',
          ...tsconfigPath
            ? {
              project: tsconfigPath,
              tsconfigRootDir: process.cwd()
            }
            : {},
          ...parserOptions as any
        }
      },
      name: 'supsign:sonar',
      plugins: {
        sonarjs: pluginSonar
      },
      rules: {
        ...pluginSonar.configs.recommended.rules
      }
    }
  ];
}
