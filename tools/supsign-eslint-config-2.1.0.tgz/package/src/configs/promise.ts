import type { FlatConfigItem } from '../types';

import { pluginPromise } from '../plugins';

export async function promise(): Promise<FlatConfigItem[]> {
  return [
    {
      name: 'supsign:promise',
      plugins: {
        promise: pluginPromise
      },
      rules: {
        ...pluginPromise.configs.recommended.rules as any,
        'promise/prefer-await-to-then': 'error'
      }
    }
  ];
}
