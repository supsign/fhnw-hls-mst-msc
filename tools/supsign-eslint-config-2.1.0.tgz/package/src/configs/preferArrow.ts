import type { FlatConfigItem } from '../types';

import { pluginPreferArrow } from '../plugins';

export async function preferArrow(): Promise<FlatConfigItem[]> {
  return [
    {
      name: 'supsign:prefer-arrow',
      plugins: {
        'prefer-arrow': pluginPreferArrow
      },
      rules: {
        'prefer-arrow/prefer-arrow-functions': [
          'error',
          {
            singleReturnOnly: true
          }
        ]
      }
    }
  ];
}
