import { isPackageExists } from 'local-pkg';
import fs from 'node:fs';
import process from 'node:process';

import type { Awaitable, FlatConfigItem, OptionsConfig, UserConfigItem } from './types';

import {
  imports,
  javascript,
  perfectionist,
  preferArrow,
  promise,
  sonar,
  stylistic,
  tailwind,
  typescript,
  unicorn,
  unocss,
  vue
} from './configs';
import { combine, interopDefault } from './utils';

const flatConfigProps: (keyof FlatConfigItem)[] = [
  'files',
  'ignores',
  'languageOptions',
  'linterOptions',
  'processor',
  'plugins',
  'rules',
  'settings'
];

/**
 * Construct an array of ESLint flat config items.
 */
export async function eslint(
  options: OptionsConfig & FlatConfigItem = {},
  ...userConfigs: Awaitable<UserConfigItem | UserConfigItem[]>[]
): Promise<UserConfigItem[]> {
  const {
    componentExts: componentExtensions = [],
    gitignore: enableGitignore = true,
    isInEditor = !!((process.env.VSCODE_PID || process.env.JETBRAINS_IDE) && !process.env.CI),
    overrides = {},
    tailwind: enableTailwind = isPackageExists('tailwindcss'),
    typescript: enableTypeScript = isPackageExists('typescript'),
    unocss: enableUnoCSS = false,
    vue: enableVue = isPackageExists('vue')
  } = options;

  const stylisticOptions = options.stylistic === false
    ? false
    : (typeof options.stylistic === 'object'
        ? options.stylistic
        : {});

  const configs: Awaitable<FlatConfigItem[]>[] = [];

  if (enableGitignore) {
    if (typeof enableGitignore === 'boolean') {
      if (fs.existsSync('.gitignore'))
        configs.push(interopDefault(import('eslint-config-flat-gitignore')).then(r => [r()]));
    } else {
      configs.push(interopDefault(import('eslint-config-flat-gitignore')).then(r => [r(enableGitignore)]));
    }
  }

  // Base configs
  configs.push(
    javascript({
      isInEditor,
      overrides: overrides.javascript
    }),
    imports({
      stylistic: stylisticOptions
    }),
    preferArrow(),
    promise(),
    sonar(),
    unicorn(),

    // Optional plugins (installed but not enabled by default)
    perfectionist()
  );

  if (enableVue) {
    componentExtensions.push('vue');
  }

  if (enableTypeScript) {
    configs.push(typescript({
      ...typeof enableTypeScript === 'boolean'
        ? {}
        : enableTypeScript,
      componentExts: componentExtensions,
      overrides: overrides.typescript
    }));
  }
  if (enableTailwind) {
    configs.push(tailwind());
  }

  if (stylisticOptions) {
    configs.push(stylistic(stylisticOptions));
  }

  if (enableUnoCSS) {
    configs.push(unocss(
      typeof enableUnoCSS === 'boolean' ? {} : enableUnoCSS
    ));
  }

  if (enableVue) {
    configs.push(vue({
      overrides: overrides.vue,
      stylistic: stylisticOptions,
      typescript: !!enableTypeScript
    }));
  }

  // User can optionally pass a flat config item to the first argument
  // We pick the known keys as ESLint would do schema validation
  const fusedConfig = flatConfigProps.reduce((acc, key) => {
    if (key in options)
      acc[key] = options[key] as any
    return acc
  }, {} as FlatConfigItem)
  if (Object.keys(fusedConfig).length)
    configs.push([fusedConfig])

  const merged = combine(
    ...configs,
    ...userConfigs,
  )

  return merged
}
