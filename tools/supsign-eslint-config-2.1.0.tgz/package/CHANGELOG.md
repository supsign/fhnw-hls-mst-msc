# Changelog


## v2.0.0

[compare changes](https://github.com/supsign/eslint-config/compare/v1.1.2...v2.0.0)

### 🚀 Enhancements

- Upgrade eslint-plugin-unicorn from 48.0.1 to 49.0.0 ([603c308](https://github.com/supsign/eslint-config/commit/603c308))
- ⚠️  Change to anftu's way to build eslint-config ([9df4f65](https://github.com/supsign/eslint-config/commit/9df4f65))

### 🩹 Fixes

- Upgrade @stylistic/eslint-plugin from 0.1.1 to 0.1.2 ([372c2b9](https://github.com/supsign/eslint-config/commit/372c2b9))

### 📖 Documentation

- Update Read Me ([6474806](https://github.com/supsign/eslint-config/commit/6474806))

### 🏡 Chore

- Update Dependencies ([4856ca8](https://github.com/supsign/eslint-config/commit/4856ca8))

#### ⚠️ Breaking Changes

- ⚠️  Change to anftu's way to build eslint-config ([9df4f65](https://github.com/supsign/eslint-config/commit/9df4f65))

### ❤️ Contributors

- Philipp.minder <philipp.minder@supsign.ch>
- Snyk-bot <snyk-bot@snyk.io>

## v1.1.2

[compare changes](https://github.com/supsign/eslint-config/compare/v1.1.1...v1.1.2)

### 🩹 Fixes

- Set `languageOptions.parserOptions.project` back to `./tsconfig.json` cause of wront interpretation ([f0e0307](https://github.com/supsign/eslint-config/commit/f0e0307))

### ❤️ Contributors

- Philipp.minder <philipp.minder@supsign.ch>

## v1.1.1

[compare changes](https://github.com/supsign/eslint-config/compare/v1.1.0...v1.1.1)

### 🩹 Fixes

- Change `parserOptions.project` true, so eslint autosearch `tsconfig.json` ([14de3d0](https://github.com/supsign/eslint-config/commit/14de3d0))
- Set `prefer-arrow` on default but just get error on single return functions ([cedade5](https://github.com/supsign/eslint-config/commit/cedade5))
- Disable `vue/script-ident` cause it have conflicts with `@stylistic` package ([2733f0f](https://github.com/supsign/eslint-config/commit/2733f0f))

### ❤️ Contributors

- Philipp.minder <philipp.minder@supsign.ch>

## v1.1.0

[compare changes](https://github.com/supsign/eslint-config/compare/v1.0.0...v1.1.0)

### 🚀 Enhancements

- Integrate 'sonarjs' plugin ([4baa7bd](https://github.com/supsign/eslint-config/commit/4baa7bd))

### 🩹 Fixes

- Add 'style/member-delimiter-style' overrides ([d5b26cb](https://github.com/supsign/eslint-config/commit/d5b26cb))

### ❤️ Contributors

- Pminder <philipp.minder@hotmail.com>

## v1.0.0


### 🚀 Enhancements

- Stable Release ([8a0adf6](https://github.com/supsign/eslint-config/commit/8a0adf6))

### ❤️ Contributors

- Philipp.minder <philipp.minder@supsign.ch>

