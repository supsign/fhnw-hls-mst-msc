// @ts-check
import eslint from './dist/index.js'

export default eslint(
  {
    vue: true,
    typescript: true,
  },
  {
    files: ['src/**/*.ts'],
    rules: {
      'perfectionist/sort-objects': 'error',
    },
  },
)
